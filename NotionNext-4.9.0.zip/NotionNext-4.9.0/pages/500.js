export default function Custom500() {
  return <div>服务器内部错误，请稍后重试。</div>
}