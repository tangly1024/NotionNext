# Codex Handoff: Figma Node 92:25

## Goal

Sync this Figma design into the larger website/codebase.

Source design:
https://www.figma.com/design/xBgF8kT7suHPjwZnhnbCYc/%E4%B8%AA%E4%BA%BA%E7%AB%99%E8%8D%89%E7%A8%BF?node-id=92-25&m=dev

Figma file key: `xBgF8kT7suHPjwZnhnbCYc`
Figma node: `92:25`
Node name: `Wireframe - 1`

## Package Contents

```text
figma-implementation/
  index.html
  styles.css
  assets/
    architecture.png
    bottom-architecture.png
    bottom-hci.png
    bottom-ixd.png
    bottom-service.svg
    bottom-ux.png
    bottom-visual-design.png
    ellipse-hci.png
    ellipse-ixd.png
    ellipse-service.svg
    ellipse-ux.png
    ellipse-visual-design.png
    logo-black-ping.svg
    logo-envis.png
    person.svg
```

## Implementation Notes

- This package is a standalone static HTML/CSS implementation because the source workspace did not contain a frontend app scaffold.
- The design was fetched through Figma MCP with `get_design_context` and `get_screenshot`.
- Figma's React/Tailwind reference output was converted into plain HTML/CSS.
- All Figma asset URLs were downloaded locally, so this package does not depend on short-lived Figma MCP asset URLs.
- The layout preserves the original 1440px design canvas and uses a small inline script to scale the canvas down responsively.
- `data-node-id` attributes were preserved on key elements to make future debugging against Figma easier.

## Suggested Online Codex Task

Use this package as the visual and structural source for implementing the Figma design in the target repository.

Recommended steps:

1. Inspect the target repository stack and styling system.
2. Recreate this screen using the target app's framework and component conventions.
3. Copy the images from `assets/` into the target app's public/static asset directory.
4. Map the plain CSS values from `styles.css` into the project's styling system.
5. Preserve the visual layout, typography, spacing, colors, and asset placement from `index.html` and `styles.css`.
6. Validate against the Figma screenshot or by comparing the standalone page.

## Local Preview

From inside this folder:

```bash
python3 -m http.server 4173
```

Then open:

```text
http://localhost:4173/index.html
```

The page also works by directly opening `index.html` in a browser.

## Design Specs Captured

- Canvas: `1440 x 1012`
- Background: `#fafafa`
- Header: white, `1440 x 161`, bottom border `#dee5ed`
- Header logo: `54 x 70`, positioned at `left: 693px; top: 20px`
- Navigation: FangSong-style serif, `16px`, `24px` line-height, `0.5px` letter spacing, `48px` gap
- Main discipline diagram: positioned at `left: 192px; top: 231px`, size approximately `587 x 494`
- Intro copy block: positioned at `left: 816px; top: 280px`, size `431 x 398`, `16px`, `1px` letter spacing
- Bottom figure: positioned at `left: 179px; top: 744px`, size approximately `1179 x 258`

## Important Caveats

- The standalone implementation intentionally avoids Tailwind or React dependencies.
- If the destination codebase already uses React/Tailwind, translate the semantic structure from `index.html` and the exact values from `styles.css`.
- Font availability may differ between systems. The CSS uses fallbacks for `SF Pro`, `Source Han Sans CN`, `Plus Jakarta Sans`, and FangSong-style Chinese serif text.
